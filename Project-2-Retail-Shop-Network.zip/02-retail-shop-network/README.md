# Retail Shop Network — Cisco Packet Tracer

A guided networking lab by Hisan Moosa.

## Overview
I simulated a retail shop with separate Sales and Stockroom subnets. Each subnet has two PCs and one Layer 2 switch. A Cisco 2911 router connects the two networks using two physical interfaces.

The goal was to understand default gateways, directly connected routes, ARP and what happens to Ethernet frames when a router forwards packets.

## Business requirements
- Sales PCs must communicate locally.
- Stockroom PCs must communicate locally.
- Sales and Stockroom must communicate across their subnets.
- The design must be tested and documented.

This lab has no internet connection, DHCP, NAT or access-control policy. Separate subnets do not by themselves block traffic between departments: the router permits inter-subnet forwarding in this configuration.

## Architecture
| Area | Subnet | Gateway | Router port |
|---|---|---|---|
| Sales | 192.168.20.0/24 | 192.168.20.1 | G0/0 |
| Stockroom | 192.168.30.0/24 | 192.168.30.1 | G0/1 |

Devices: one 2911 router, two 2960-24TT switches, four PC-PT endpoints. The supplied CLI hostnames are R1-SHOP, S1-switch (Sales) and S2-Switch (Stockroom). Workspace display labels may differ from CLI hostnames.

## Topology and evidence
![Supplied topology](topology/supplied-topology.png)

The supplied topology image shows red router links. Later pasted interface output reports both interfaces up/up and cross-subnet ping succeeds. The image is retained unchanged and is not a final operational-state screenshot.

[Combined JPG evidence](screenshots/project-2-network-evidence.jpg) contains the topology and faithfully recreated text panels for ping, interface status and routing. Those panels are rendered from learner-pasted output, not original CLI screenshots.

## Configuration and addressing
- [IP and MAC addressing](addressing/ip-addressing.md)
- [Physical connection plan](topology/connection-list.md)
- [Router configuration](configurations/R1-SHOP-config.txt)
- [Sales switch configuration](configurations/S1-switch-config.txt)
- [Stockroom switch configuration](configurations/S2-Switch-config.txt)
- [Configuration provenance and security status](configurations/README.md)

Static addresses were used. No switch management IPs are configured. Both networks are directly connected to the router, so no static routes or dynamic routing protocol are needed between them.

## Verification
[Results and repeatable tests](verification/test-results.md) record same-subnet and cross-subnet ping, tracert, routing entries, interface status and ARP output. Connectivity evidence is from the learner's supplied outputs; it was not independently executed during packaging.

## Troubleshooting
[Incident exercises](troubleshooting/incident-report.md) cover a wrong PC gateway and an administratively disabled router interface. These were imaginary guided scenarios, not confirmed injected faults. A subsequent successful ping was supplied, but it does not prove that an actual fault was introduced.

## Packet flow
[Simple packet-flow explanation](documentation/packet-flow.md) explains why PC IP addresses stay the same while Ethernet source and destination MAC addresses change at the router.

## Security
The reviewed configuration exports contain no enable secrets, SSH, ACLs or port security. The learner later requested and received router enable-secret setup instructions, then uploaded a newer .pkt file. There is no subsequent router configuration export or password-test output confirming that change. Do not claim that it was verified. See configurations/README.md.

## Lessons learned
- A PC uses the gateway in its own subnet to reach another subnet.
- A same-subnet ping does not verify a PC's default gateway setting.
- Routing tables choose paths; ARP supplies local next-hop MAC addresses.
- Switches learn source MACs and forward using destination MACs.
- A router forwards between these two directly connected networks automatically.
- Interface shutdown prevents connectivity even if IP settings are correct.

## Limitations and improvements
The single router is a point of failure for inter-subnet traffic. Each switch is a point of failure for its attached PCs. There is no redundant path. A larger shop could later need DHCP, device access protection, monitoring and policy controls. These are future improvements, not implemented features.

Packet Tracer simulates device behaviour; command availability can differ from real equipment. The supplied .pkt is preserved unchanged. It has not been independently opened, decoded or run during this packaging task. Text exports describe their own capture time and may predate the binary's latest changes.

## Open and retest
Open topology/retail-shop-network.pkt in Cisco Packet Tracer. Follow verification/test-results.md. Save device settings with copy running-config startup-config and save the .pkt separately.

## Portfolio status
The ZIP includes documentation, configuration exports, addressing, evidence and the latest supplied .pkt. It has not been published to GitHub. Optional remaining evidence: an all-green final topology screenshot, post-password router export/test, confirmation of actual switch uplink port numbers and a post-reopen Project 2 ping test.
