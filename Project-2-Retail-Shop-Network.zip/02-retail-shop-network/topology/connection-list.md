# Physical connection plan

| Device port | Connected port |
|---|---|
| SALES-PC1 FastEthernet0 | Sales switch Fa0/1 |
| SALES-PC2 FastEthernet0 | Sales switch Fa0/2 |
| Sales switch Gi0/1 | R1-SHOP G0/0 |
| STOCK-PC1 FastEthernet0 | Stockroom switch Fa0/1 |
| STOCK-PC2 FastEthernet0 | Stockroom switch Fa0/2 |
| Stockroom switch Gi0/1 | R1-SHOP G0/1 |

Cable: copper straight-through. No direct switch-to-switch link is part of this design.

This is the instructed port plan. The supplied topology confirms device relationships but does not display interface labels. The PC and switch-uplink port assignments have not been independently confirmed from the binary file.
