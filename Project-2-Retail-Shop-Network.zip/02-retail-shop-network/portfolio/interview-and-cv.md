# Interview review

1. Why is the router needed? It connects the different Sales and Stockroom subnets.
2. Which gateway does Sales use? 192.168.20.1, the router interface in Sales' own subnet.
3. Are static routes needed? No: both networks are directly connected to this router.
4. What changes at the router? Ethernet source/destination MACs are replaced for the outgoing link; endpoint IPs remain the same here; TTL decreases.
5. ARP table versus MAC table? ARP maps IP to MAC; a switch MAC table maps MAC to port.
6. Best test of a gateway correction? Reach a PC in the other subnet; same-subnet ping alone is insufficient.

Review areas: choosing the local gateway rather than destination PC address; matching destination subnets to outgoing ports; ARP/MAC table distinction. These required guided correction during learning.

## CV entry
Retail Shop Network — Cisco Packet Tracer
- Built and simulated two IPv4 subnets with four PCs, two Layer 2 switches and a Cisco router.
- Configured gateway interfaces and verified inter-subnet connectivity using ping, tracert, routing tables and ARP output.
- Diagnosed wrong-gateway and disabled-interface scenarios in guided troubleshooting exercises.

Do not claim production deployment, OSPF, NAT, DHCP, custom VLANs, SSH or verified password security from this evidence.
