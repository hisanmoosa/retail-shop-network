# Evidence-based progress

| Skill | Status | Evidence |
|---|---|---|
| Two-subnet design | Demonstrated with guidance | Topology and address plan |
| Router interface IPv4 | Demonstrated | Configuration and up/up output |
| Cross-subnet tests | Demonstrated | Ping, tracert outputs |
| Connected/local routes | Practised; revise | Corrected interface-selection answers |
| Gateway selection | Practised; revise | Initially confused destination with gateway |
| Packet and frame addresses | Demonstrated with guidance | Correct follow-up responses |
| ARP interpretation | Demonstrated with guidance | PC/router ARP discussion |
| Troubleshooting | Guided exercise completed | Two imaginary tickets |
| Documentation | Package prepared | Learner should review and explain it |
| Privileged password | Not verified for latest state | Instruction supplied; later export absent |
| GitHub publication | Not done | No repository created |

This is not an independent proficiency or hiring-readiness score. Guided performance cannot establish independent troubleshooting ability. Rebuild or explain the network without copying instructions to strengthen the evidence.

## Close-out
- [x] Topology built and IP interfaces configured
- [x] Same-subnet and cross-subnet ping evidence
- [x] Routing, interface, ARP and trace output supplied
- [x] Guided faults discussed
- [x] Three configuration exports prepared from supplied text
- [x] Latest supplied .pkt included unchanged
- [x] README, addressing, test results and CV wording prepared
- [ ] Independently reopen/retest the saved Project 2 file and record result
- [ ] Optional: final all-green screenshot, visible port labels
- [ ] Optional: post-password router configuration and password test
- [ ] Publish to GitHub and review rendered README
