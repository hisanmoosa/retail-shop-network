# GitHub upload guide

Suggested repository name: retail-shop-network-packet-tracer.

Create a repository when ready. Upload this folder's contents so README.md is at the repository root; preserve the subfolders and relative links. Include the .pkt so a reviewer can open the lab.

Review the README and evidence notes first. The provided topology image predates operational output. Describe password configuration only after checking the current device state. Do not publish real credentials; all settings here belong to a training lab.

Use commits that reflect actual work, for example Add retail network lab and verification documents when uploading this completed package. Do not manufacture an incremental history for earlier steps that were not committed.

After uploading, check image links, download/open the .pkt and inspect configuration files. No repository was created or published by this task.
