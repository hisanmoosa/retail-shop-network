# Configuration provenance

These three text exports are based on complete running-configuration outputs supplied in chat. CLI prompts, byte-count headers and Building configuration messages were removed. Repeated blank/comment-only separators were shortened; configuration commands and values were retained.

R1-SHOP-config.txt predates the later enable-secret instructions. It is a reviewed connectivity configuration, not a newly verified post-password export. Both switch exports have their supplied final CLI hostnames. Their running configurations contain no enable secrets or interface descriptions.

No commands were invented or added to these exports. In particular, enable secret ShopLab123 was suggested later but was not confirmed by a supplied final show running-config output. The latest uploaded .pkt may contain that change; it was not decoded or run here. Do not treat the text files as guaranteed byte-for-byte exports from that binary.

To update the router export: use show running-config after the password change, copy the full output through end, then replace R1-SHOP-config.txt. A successful disable/enable password test can verify privileged access. This does not establish SSH or console login security.

The absence of an IP address on a Layer 2 switch does not prevent ordinary frame forwarding. VLAN 1 SVI shutdown concerns its virtual interface, not every physical port.
