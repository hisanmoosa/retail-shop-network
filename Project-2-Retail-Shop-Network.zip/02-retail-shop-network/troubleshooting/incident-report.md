# Guided troubleshooting exercises

Both scenarios below were presented as imaginary tickets. They were not confirmed fault injections into the working .pkt.

## Ticket RET-001 — One Sales PC cannot reach Stockroom
Symptoms: SALES-PC1 can reach its local PC and .20.1, but not Stockroom. SALES-PC2 can reach Stockroom.
Evidence supplied: SALES-PC1 IP .20.11/24, gateway .20.254; router Sales interface .20.1.
Learner diagnosis: check whether the PC gateway matches its router interface.
Correction: set the gateway to 192.168.20.1.
Verification: ping 192.168.30.11 from SALES-PC1, not only .20.1.
Reason: reaching a same-subnet router IP does not require the PC's default gateway setting; reaching another subnet does.

## Ticket RET-002 — Both departments work locally but cannot reach each other
Symptoms: local PC communication works on both sides; inter-subnet communication fails.
Evidence supplied: G0/0 up/up; G0/1 administratively down/down.
Learner diagnosis: G0/1 is disabled.
Fix in interface configuration mode: no shutdown.
Verification: show ip interface brief, then a cross-subnet ping.
Follow-up evidence: learner supplied both interfaces up/up and a 4/4 successful Sales-to-Stockroom ping. This confirms working connectivity at that point, not that a real fault had previously existed.

## Evidence-based checks
Confirm source PC, cable/link status, PC IP/mask/gateway, router interfaces and connected routes. Use ping and tracert to narrow the problem. Verify the intended user path after any fix, save settings and record the result.
