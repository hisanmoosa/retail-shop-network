# Address plan and observed MACs

| Device | Interface | IPv4 | Mask | Default gateway | MAC from router ARP |
|---|---|---|---|---|---|
| R1-SHOP | G0/0 | 192.168.20.1 | 255.255.255.0 | Not configured | 0000.0CA3.BB01 |
| R1-SHOP | G0/1 | 192.168.30.1 | 255.255.255.0 | Not configured | 0000.0CA3.BB02 |
| SALES-PC1 | FastEthernet0 | 192.168.20.11 | 255.255.255.0 | 192.168.20.1 | 00D0.D359.5647 |
| SALES-PC2 | FastEthernet0 | 192.168.20.12 | 255.255.255.0 | 192.168.20.1 | 0090.2106.4306 |
| STOCK-PC1 | FastEthernet0 | 192.168.30.11 | 255.255.255.0 | 192.168.30.1 | 0007.EC24.C02A |
| STOCK-PC2 | FastEthernet0 | 192.168.30.12 | 255.255.255.0 | 192.168.30.1 | 0090.0C11.53EB |
| S1-switch | VLAN 1 SVI | Unassigned | N/A | Not configured | N/A |
| S2-Switch | VLAN 1 SVI | Unassigned | N/A | Not configured | N/A |

PC masks/gateways follow the lab plan; MAC and IP mappings are supported by the pasted router ARP output. No per-PC ipconfig capture was supplied. DNS is left blank for IP-based tests.

| Subnet | Usable range | Broadcast |
|---|---|---|
| 192.168.20.0/24 | 192.168.20.1–192.168.20.254 | 192.168.20.255 |
| 192.168.30.0/24 | 192.168.30.1–192.168.30.254 | 192.168.30.255 |

## VLANs
Both switches use their default VLAN 1; no custom VLANs or trunk configuration were added. The router separates the two Layer 2 broadcast domains. Using VLAN ID 1 on both separate switches does not merge them across the router.
