# Test matrix and interpretation

Source labels follow the lesson context, rather than independent PC configuration inspection.

| Source | Destination | Expected | Observed evidence |
|---|---|---|---|
| SALES-PC1 | SALES-PC2 .20.12 | Success, local switching | 4 replies, 0% loss |
| SALES-PC1 | Router .20.1 | Success | 4 replies, 0% loss |
| SALES-PC1 | Router .30.1 | Success | 4 replies, 0% loss; this is still a router address |
| SALES-PC1 | STOCK-PC1 .30.11 | Success, routed | Repeated pings: 4 replies, 0% loss, TTL 127 |
| STOCK-PC1 | SALES-PC1 .20.11 | Success, routed | 4 replies, 0% loss, TTL 127 |
| STOCK-PC1 | SALES-PC2 .20.12 | Success, routed | First attempt lost one; repeat 4 replies, 0% loss |
| STOCK-PC2 | STOCK-PC1 .30.11 | Success, local switching | 4 replies, 0% loss, TTL 128 |
| STOCK-PC2 | SALES-PC1 .20.11 | Success, routed | 4 replies, 0% loss, TTL 127 |
| STOCK-PC2 | tracert to .20.11 | Gateway then destination | .30.1 then .20.11 |

Initial isolated timeouts are consistent with ARP learning, but no packet capture was supplied to prove the cause. Repeated success showed no continuing loss. TTL 127 is consistent with these simulated PCs' replies passing through one router; TTL alone is not a universal proof of source location.

## Repeat after reopening
1. Check the source PC with ipconfig before each test.
2. On SALES-PC1, ping .20.12 and .30.11.
3. On STOCK-PC2, ping .30.11 and .20.11.
4. On the router, run show ip interface brief, show ip route and show ip arp.
5. Expect G0/0 and G0/1 up/up, two connected /24 routes and two local /32 routes.
6. Repeat a ping if address learning causes a first timeout; investigate recurring loss.

Post-reopen Project 2 tests have not been explicitly supplied. No all-pairs test coverage or internet access is claimed.
