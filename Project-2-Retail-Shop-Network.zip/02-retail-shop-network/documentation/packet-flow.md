# Packet flow in simple English

Example: SALES-PC1 (192.168.20.11) sends to STOCK-PC1 (192.168.30.11).

1. Sales PC checks its /24 mask and sees the destination is in another subnet.
2. It uses ARP to find its own gateway's MAC, 192.168.20.1.
3. It sends an Ethernet frame through the Sales switch to router G0/0.
4. The router removes the incoming Ethernet frame and checks the destination IP in its routing table.
5. The connected 192.168.30.0/24 route points to G0/1.
6. The router uses ARP for STOCK-PC1 if needed, reduces IP TTL by one and builds a new Ethernet frame.
7. The Stockroom switch forwards the frame to STOCK-PC1. The reply returns through the router in the reverse direction.

| Field | Sales PC to router | Router to Stockroom PC |
|---|---|---|
| Source IP | 192.168.20.11 | 192.168.20.11 |
| Destination IP | 192.168.30.11 | 192.168.30.11 |
| Source MAC | 00D0.D359.5647 | 0000.0CA3.BB02 |
| Destination MAC | 0000.0CA3.BB01 | 0007.EC24.C02A |

No NAT is configured here, so endpoint source/destination IPs remain unchanged. Router interfaces have different MAC addresses. ARP broadcasts remain in the local broadcast domain; the router does not forward them to the other subnet.

Memory: routing table selects a route/interface; ARP finds the local next-hop MAC; the switch MAC table identifies a switch port.
