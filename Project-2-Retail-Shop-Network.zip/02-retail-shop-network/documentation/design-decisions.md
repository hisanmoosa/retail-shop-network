# Design review

Two physical router ports make the subnet boundary easy to see in a beginner lab. The networks are in the same shop; different subnets do not imply geographically distant sites.

The 2960 Layer 2 switches forward local frames. They need no management IP for this role. The router provides gateway functions for remote-subnet traffic. No routing protocol is running just because its abbreviation appears in the show ip route legend.

Failure cases:
- Router failure: local communication on each switch can continue, but cross-subnet communication fails.
- Sales switch failure: its PCs lose local and routed access; Stockroom local switching can continue.
- Stockroom switch failure: the reverse applies.

The /24 networks are easy for learning but larger than needed for two PCs; tighter subnet sizing is a later exercise. No ACL means this is separation of broadcast domains, not enforced department access isolation.

Future extensions: DHCP, device access protection, monitored logs, secure management and appropriate access policies. None is claimed as implemented here. Real retail payment systems require additional requirements and controls beyond this training exercise.
