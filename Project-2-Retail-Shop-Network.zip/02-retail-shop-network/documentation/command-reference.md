# Commands used

| Device | Command | Purpose | Expected result / common mistake |
|---|---|---|---|
| IOS | enable | Enter privileged mode | Prompt changes from > to # |
| IOS | configure terminal | Enter settings mode | Use at #, not > |
| IOS | hostname NAME | Set CLI name | Workspace label alone does not change this |
| Router | interface g0/0 | Select Sales interface | Prompt becomes (config-if)# |
| Router | ip address 192.168.20.1 255.255.255.0 | Set Sales gateway | Use in interface mode; G0/1 uses .30.1 |
| Router | no shutdown | Enable selected interface | Does not repair a missing cable |
| IOS | description TEXT | Label a connection | Does not alter traffic flow |
| IOS | end | Leave configuration mode | Returns to # |
| Router | show ip interface brief | Check addresses and state | Both used interfaces up/up |
| Router | show ip route | Check known paths | C /24 and L /32 for each side |
| Router | show ip arp | View IP-to-MAC mappings | Uses IOS syntax, not PC arp -a |
| IOS | show running-config | View active settings | Use at #; Space advances --More-- |
| IOS | copy running-config startup-config | Save active settings | Accept destination filename with Enter |
| PC | ipconfig | Check source IP and gateway | Confirm which PC you are testing from |
| PC | ping ADDRESS | Test ICMP request/reply | An allowed reply demonstrates reachability |
| PC | arp -a | View PC ARP cache | Maps IP to MAC, not MAC to port |
| PC | tracert ADDRESS | Inspect IP hops | Gateway then remote PC in this lab |

Later suggested router command: enable secret ShopLab123. Its application was not verified in a post-change export. Practice passwords must not be reused for real systems. Save the Packet Tracer file separately with Ctrl+S.
