# Package manifest

Latest source: Retail Shop Network(1).pkt. Binary preserved unchanged.
SHA-256: e7389d37a07d8175f3098cb5e46df7415e453fb0bc52256616f7509e94f72ee8

- README.md
- addressing/ip-addressing.md
- configurations/R1-SHOP-config.txt
- configurations/README.md
- configurations/S1-switch-config.txt
- configurations/S2-Switch-config.txt
- documentation/command-reference.md
- documentation/design-decisions.md
- documentation/packet-flow.md
- portfolio/github-guide.md
- portfolio/interview-and-cv.md
- portfolio/progress-and-checklist.md
- screenshots/project-2-network-evidence.jpg
- topology/connection-list.md
- topology/retail-shop-network.pkt
- topology/supplied-topology.png
- troubleshooting/incident-report.md
- verification/cross-subnet-ping.txt
- verification/pc-arp-and-trace.txt
- verification/router-arp-table.txt
- verification/router-interface-status.txt
- verification/routing-table.txt
- verification/test-results.md
